from PIL import Image

image_file = "images/output1.png"
img = Image.open(image_file).convert('RGB')


with open('binary_matrix.txt', 'r') as f:
    matrix_route = [[int(num) for num in line.split(' ')] for line in f]
matrix_route = [[int(char) for char in string] for string in matrix_route]

pixdata = img.load()

for y in range(img.size[1] - 1):
    for x in range(img.size[0] - 1):
        if matrix_route[y][x] == 30:
            pixdata[x + 1, y + 1] = (255, 0, 0)
            pixdata[x, y + 1] = (255, 0, 0)
            pixdata[x - 1, y + 1] = (255, 0, 0)
            pixdata[x + 1, y] = (255, 0, 0)
            pixdata[x, y] = (255, 0, 0)
            pixdata[x - 1, y] = (255, 0, 0)
            pixdata[x + 1, y - 1] = (255, 0, 0)
            pixdata[x, y - 1] = (255, 0, 0)
            pixdata[x - 1, y - 1] = (255, 0, 0)


img.save("route.png")