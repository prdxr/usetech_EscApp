from PIL import Image
import numpy as np

input_file_path = "matrix_zjato.txt" 

try:
    with open(input_file_path, "r") as file:
        lines = file.readlines()
        matrix = [list(map(int, line.strip().split())) for line in lines]
except FileNotFoundError:
    print(f"Файл '{input_file_path}' не найден.")
    exit(1)
except Exception as e:
    print(f"Произошла ошибка при чтении файла: {str(e)}")
    exit(1)

binary_matrix = np.array(matrix, dtype=np.uint8)
image = Image.fromarray(binary_matrix, mode='L') 

output_file_path = "output_image.jpg"
image.save(output_file_path)

print(f"Черно-белая картинка сохранена в {output_file_path}")

for row in grid: 
    for i in range(len(row)):
        if row[i] == 0:            
            row[i] = 255
        elif row[i] == 255:            
            row[i] = 0

cols, rows = len(grid[0]), len(grid)
new_grid =[[0]*int(cols/2) for _ in range(int(rows/2))]
for i in range(int(rows/2) ):    
    for j in range(int(cols/2)):
        sr_znach = grid[i*2][j*2] + grid[i*2+1][j*2+1] + grid[i*2+1][j*2] + grid[i*2][j*2+1]        
        new_grid[i][j] = 255 if int(sr_znach/4)>0 else 0