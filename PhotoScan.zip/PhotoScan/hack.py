
from heapq import *
import numpy as np
from PIL import Image


def get_next_nodes(x, y):
    check_next_node = lambda x, y: True if 0 <= x < cols and 0 <= y < rows else False
    ways = [-1, 0], [0, -1], [1, 0], [0, 1], [1, 1], [-1, 1], [1, -1], [-1, -1]
    return [(grid[y + dy][x + dx], (x + dx, y + dy)) for dx, dy in ways if check_next_node(x + dx, y + dy)]

def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

cols, rows = 1280, 586 #размерность поля, брать из картинки
TILE = 60 #азмерность фигур на поле
with open('binary_matrix.txt', 'r') as f:
    grid = [[int(num) for num in line.split(' ')] for line in f]
grid = [[int(char) for char in string ] for string in grid]

for x in range(img.size[0]):
    for y in range(img.size[1]):
        if grid[x][y] == 0:
            grid[x][y] = 254
        elif grid[x][y] == 255:
            grid[x][y] = 0
        elif grid[x][y] == 254:
            grid[x][y] = 255


# print(grid)
# input()

# dict of adjacency lists
graph = {}
for y, row in enumerate(grid):
    for x, col in enumerate(row):
        graph[(x, y)] = graph.get((x, y), []) + get_next_nodes(x, y)

# BFS settings
start = (500, 500) #начало алгоритма
goal = (1000, 325) #конец алгоритма
#goal2 = (3,7)
queue = []
heappush(queue, (0, start))
cost_visited = {start: 0}
visited = {start: None}
queuea = []
need_path = []
while True:
    # Dijkstra logic
    if queue:
        cur_cost, cur_node = heappop(queue)
        if cur_node == goal:
            queue = []
            continue

        next_nodes = graph[cur_node]
        for next_node in next_nodes:
            neigh_cost, neigh_node = next_node
            new_cost = cost_visited[cur_node] + neigh_cost

            if neigh_node not in cost_visited or new_cost < cost_visited[neigh_node]:
                priority = new_cost + heuristic(neigh_node, goal)
                heappush(queue, (priority, neigh_node))
                cost_visited[neigh_node] = new_cost
                visited[neigh_node] = cur_node
    #print(visited)
    path_head, path_segment = cur_node, cur_node
    need_path = queue
    queueb = []
    #heappush(queueb, path_segment)
    #print(start)#pg.draw.circle(sc, pg.Color('blue'), *get_circle(*start))
    #need_path.add(path_segment)
    while path_segment:
        heappush(queueb, path_segment)
        #print(path_segment) #pg.draw.circle(sc, pg.Color('brown'), *get_circle(*path_segment))
        path_segment = visited[path_segment]
    if(queuea == queueb):
        need_path = queuea
        grid1 = grid
        for element in need_path:
            gridx, gridy = element[0], element[1]
            grid1[element[1]][element[0]] = 30
        break
    else:
        queuea = queueb

queuea = []


output_file_path = "binary_matrix1.txt"
np.savetxt(output_file_path, grid1, fmt='%d', delimiter=' ')
print(f"Binary matrix saved to {output_file_path}")

image_file = "images/output1.png"
img = Image.open(image_file).convert('RGB')


# with open('binary_matrix.txt', 'r') as f:
#     matrix_route = [[int(num) for num in line.split(' ')] for line in f]
# matrix_route = [[int(char) for char in string] for string in matrix_route]

pixdata = img.load()

for y in range(img.size[1] - 1):
    for x in range(img.size[0] - 1):
        if grid1[y][x] == 30:
            pixdata[x + 1, y + 1] = (255, 0, 0)
            pixdata[x, y + 1] = (255, 0, 0)
            pixdata[x - 1, y + 1] = (255, 0, 0)
            pixdata[x + 1, y] = (255, 0, 0)
            pixdata[x, y] = (255, 0, 0)
            pixdata[x - 1, y] = (255, 0, 0)
            pixdata[x + 1, y - 1] = (255, 0, 0)
            pixdata[x, y - 1] = (255, 0, 0)
            pixdata[x - 1, y - 1] = (255, 0, 0)


img.save("route.png")


# print(need_path)
    #print(path_head) #pg.draw.circle(sc, pg.Color('magenta'), *get_circle(*path_head))