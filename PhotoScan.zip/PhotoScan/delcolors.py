from PIL import Image

image_file = "plan2.jpg"
img = Image.open(image_file).convert('RGBA')

pixdata = img.load()

for y in range(img.size[1]):
   for x in range(img.size[0]):
      alpha = pixdata[x, y][3]
      pix_r = pixdata[x, y][0]
      pix_g = pixdata[x, y][1]
      pix_b = pixdata[x, y][2]
      if not all(min(pix_b, pix_g, pix_r) + 20 >= pixl for pixl in [pix_b, pix_g, pix_r]):
         pixdata[x, y] = (255, 255, 255, alpha)

img.save("output1.png")