import cv2
import numpy as np
from PIL import Image

image_file = "images/small_pdf.jpg"
img = Image.open(image_file).convert('RGB')

pixdata = img.load()



for y in range(img.size[1]):
   for x in range(img.size[0]):
      pix_r = pixdata[x, y][0]
      pix_g = pixdata[x, y][1]
      pix_b = pixdata[x, y][2]
      if not all(min(pix_b, pix_g, pix_r) + 20 >= pixl for pixl in [pix_b, pix_g, pix_r]):
         pixdata[x, y] = (255, 255, 255)


img.save("images/output1.png")
image_path = "images/output1.png"
def image_to_binary_matrix(image_path):
   image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

   if image is None:
      print("Error: Unable to load the image.")
      return None

   _, binary_matrix = cv2.threshold(image, 128, 255, cv2.THRESH_BINARY)
   return binary_matrix

binary_matrix = image_to_binary_matrix(image_path)

if binary_matrix is not None:
   output_file_path = "binary_matrix.txt"
   np.savetxt(output_file_path, binary_matrix, fmt='%d', delimiter=' ')
   print(f"Binary matrix saved to {output_file_path}")