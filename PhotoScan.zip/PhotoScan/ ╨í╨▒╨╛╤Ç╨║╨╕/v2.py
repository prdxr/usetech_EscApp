import cv2
import numpy as np
from heapq import *
from PIL import Image

image_file = "images/small_pdf.jpg"
img = Image.open(image_file).convert('RGB')
img = img.resize(size=[int(img.size[0] * 0.5), int(img.size[1] * 0.5)])
pixdata = img.load()

#Черно-белый вид матрицы, с учетом у§  даления цветных объектов
for y in range(img.size[1]):
   for x in range(img.size[0]):
      pix_r = pixdata[x, y][0]
      pix_g = pixdata[x, y][1]
      pix_b = pixdata[x, y][2]
      if not all(min(pix_b, pix_g, pix_r) + 20 >= pixl for pixl in [pix_b, pix_g, pix_r]):
         pixdata[x, y] = (255, 255, 255)

img.save("images/output1.png")
image_path = "images/output1.png"

#Картинка в матрицу
def image_to_binary_matrix(image_path):
   image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

   _, binary_matrix = cv2.threshold(image, 128, 255, cv2.THRESH_BINARY)
   return binary_matrix

binary_matrix = image_to_binary_matrix(image_path)

# получаем проценты из юнити
person_x = 0.1
person_y = 0.1
exit_x = 0.7
exit_y = 0.7
focus_x = 0.3
focus_y = 0.3
binary_matrix[int(img.size[1] * person_y)][int(img.size[0] * person_x)] = 2 # стартовая позиция
binary_matrix[int(img.size[1] * exit_y)][int(img.size[0] * exit_x)] = 3 # выход 
binary_matrix[int(img.size[1] * focus_y)][int(img.size[0] * focus_x)] = 15 # задымление

# создаем пустые клетки возле выхода и входа
for x in range(int(img.size[1] * person_y) - 10, int(img.size[1] * person_y) + 10):
   for y in range(int(img.size[0] * person_x) - 10, int(img.size[0] * person_x) + 10):
      if x == int(img.size[1] * person_y) and y == int(img.size[0] * person_x):
         continue
      binary_matrix[x][y] = 255

for x in range(int(img.size[1] * exit_y) - 10, int(img.size[1] * exit_y) + 10):
   for y in range(int(img.size[0] * exit_x) - 10, int(img.size[0] * exit_x) + 10):
      if x == int(img.size[1] * exit_y) and y == int(img.size[0] * exit_x):
         continue
      binary_matrix[x][y] = 255

if binary_matrix is not None:
   output_file_path = "binary_matrix.txt"
   np.savetxt(output_file_path, binary_matrix, fmt='%d', delimiter=' ')
   print(f"Binary matrix saved to {output_file_path}")

cols = img.size[0]
rows = img.size[1]
def get_next_nodes(x, y):
   check_next_node = lambda x, y: True if 0 <= x < cols and 0 <= y < rows else False
   ways = [-1, 0], [0, -1], [1, 0], [0, 1], [1, 1], [-1, 1], [1, -1], [-1, -1]
   return [(grid[y + dy][x + dx], (x + dx, y + dy)) for dx, dy in ways if check_next_node(x + dx, y + dy)]

def heuristic(a, b):
   return abs(a[0] - b[0]) + abs(a[1] - b[1])

TILE = 60 #азмерность фигур на поле
with open('binary_matrix.txt', 'r') as f:
   grid = [[int(num) for num in line.split(' ')] for line in f]
grid = [[int(char) for char in string ] for string in grid]

for x in range(cols):
   for y in range(rows):
      if grid[y][x] == 0:
         grid[y][x] = 254
      elif grid[y][x] == 255:
         grid[y][x] = 0
      elif grid[y][x] == 254:
         grid[y][x] = 255

graph = {}
for y, row in enumerate(grid):
   for x, col in enumerate(row):
      graph[(x, y)] = graph.get((x, y), []) + get_next_nodes(x, y)


start = (int(img.size[1] * person_y), int(img.size[0] * person_x)) #начало алгоритма
goal = (int(img.size[1] * exit_y), int(img.size[0] * exit_x)) #конец алгоритма
queue = []
heappush(queue, (0, start))
cost_visited = {start: 0}
visited = {start: None}
queuea = []
need_path = []
while True:
   if queue:
      cur_cost, cur_node = heappop(queue)
      if cur_node == goal:
            queue = []
            continue

      next_nodes = graph[cur_node]
      for next_node in next_nodes:
            neigh_cost, neigh_node = next_node
            new_cost = cost_visited[cur_node] + neigh_cost

            if neigh_node not in cost_visited or new_cost < cost_visited[neigh_node]:
               priority = new_cost + heuristic(neigh_node, goal)
               heappush(queue, (priority, neigh_node))
               cost_visited[neigh_node] = new_cost
               visited[neigh_node] = cur_node
   path_head, path_segment = cur_node, cur_node
   need_path = queue
   queueb = []
   while path_segment:
      heappush(queueb, path_segment)
      path_segment = visited[path_segment]
   if(queuea == queueb):
      need_path = queuea
      grid1 = grid
      for element in need_path:
            gridx, gridy = element[0], element[1]
            grid1[element[1]][element[0]] = 30
      break
   else:
      queuea = queueb

queuea = []


output_file_path = "binary_matrix1.txt"
np.savetxt(output_file_path, grid1, fmt='%d', delimiter=' ')
print(f"Binary matrix saved to {output_file_path}")

image_file = "images/output1.png"
img = Image.open(image_file).convert('RGB')
pixdata = img.load()

for y in range(img.size[1] - 1):
   for x in range(img.size[0] - 1):
      if grid1[y][x] == 30:
         pixdata[x + 1, y + 1] = (255, 0, 0)
         pixdata[x, y + 1] = (255, 0, 0)
         pixdata[x - 1, y + 1] = (255, 0, 0)
         pixdata[x + 1, y] = (255, 0, 0)
         pixdata[x, y] = (255, 0, 0)
         pixdata[x - 1, y] = (255, 0, 0)
         pixdata[x + 1, y - 1] = (255, 0, 0)
         pixdata[x, y - 1] = (255, 0, 0)
         pixdata[x - 1, y - 1] = (255, 0, 0)


img.save("route.png")