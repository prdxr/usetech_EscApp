import pygame
import numpy as np

# Constants
WIDTH, HEIGHT = 1200, 700  # Adjust the display window size
GRID_SIZE = 2  # Adjust the grid cell size
SMOKE_PROB = 0.1
# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (150, 150, 150)

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Smoke Propagation Simulation")

# Load the grid matrix from the file
with open('../matrix_zjato.txt', 'r') as f:
    grid = np.array([[int(num) for num in line.split(' ')] for line in f])

for row in grid:
    for i in range(len(row)):
        if row[i] == 0:
            row[i] = 255
        elif row[i] == 255:
            row[i] = 0

# Find the starting point for smoke (where 10 is located in the matrix)
start_row, start_col = np.where(grid == 10)
if start_row.size > 0:
    start_row, start_col = start_row[0], start_col[0]
else:
    start_row, start_col = 0, 0

# Function to spread smoke
def spread_smoke():
    new_grid = np.copy(grid)

    for row in range(1, grid.shape[0] - 1):
        for col in range(1, grid.shape[1] - 1):
            if grid[row, col] == 0:
                continue

            smoke_neighbors = (
                grid[row - 1, col] == 10 or
                grid[row + 1, col] == 10 or
                grid[row, col - 1] == 10 or
                grid[row, col + 1] == 10
            )
            if smoke_neighbors and np.random.random() < SMOKE_PROB:
                new_grid[row, col] = 10

    return new_grid

# Set the starting point as smoke
grid[start_row, start_col] = 10

running = True
clock = pygame.time.Clock()
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    new_grid = spread_smoke()

    screen.fill(BLACK)

    for row in range(grid.shape[0]):
        for col in range(grid.shape[1]):
            if new_grid[row, col] == 0:
                color = BLACK
            elif new_grid[row, col] == 10:
                color = GRAY
            else:
                color = WHITE

            pygame.draw.rect(
                screen, color, (col * GRID_SIZE, row * GRID_SIZE, GRID_SIZE, GRID_SIZE)
            )

    pygame.display.flip()
    grid = new_grid
    clock.tick(100)

pygame.quit()
